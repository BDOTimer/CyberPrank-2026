class X: pass


