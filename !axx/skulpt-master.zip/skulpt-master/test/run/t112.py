a = ()
print a
