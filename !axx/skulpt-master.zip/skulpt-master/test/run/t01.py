print 234
